// src/Tours.js
import React from 'react';
import './Tours.css';

const Tours = () => (

<>
  <div>
    <h2 className='h22'>Tours Page - Coming Soon!</h2>
    <p className='p22'>Stay tuned for exciting tours and adventures!</p>
  </div>
  </>
);

export default Tours;
