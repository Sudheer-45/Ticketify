function toggleWalletDropdown() {
    var dropdown = document.getElementById('wallet-dropdown');
    dropdown.classList.toggle('show');
  }
  